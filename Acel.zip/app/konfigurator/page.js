
import React from 'react'
import Main from '../components/configurator/Main'
import Modal from './Modal'

function page() {


  
  return (
    <div className="w-screen h-screen relative flex justify-center items-center">  
   
      <Main />
       <Modal/> 

    </div>

  )
}

export default page