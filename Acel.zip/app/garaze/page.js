
import Filters from "../components/garaze/Filters"

function page() {

  return (
    <main className="flex flex-col py-10">
      <Filters/>
    </main>
  )
}

export default page